#include <iostream>
#include <limits> // Para manejar errores de entrada como la actividad anterior
#include <wchar.h>  // importante incluir �stas librerias para poder respetar el acento al igual que usar el setlocale(LC_ALL, ""); antes de un cout 
#include <locale.h>
using namespace std; // sigo utilizando �sta sentencia por el hecho de que me confunde mas colocar el std:: 

int main() {
    double num1, num2; // Para manejar tanto enteros como decimales utilizar� double �ste caso para que sea un poco diferente del float 
    setlocale(LC_ALL, "");
    cout << "Escribe el primer n�mero: ";
    if (!(cin >> num1)) { // Validaci�n de entrada
    setlocale(LC_ALL, "");
        cout << "Error: Por favor, ingrese un n�mero v�lido." << endl;
        return 1; // Termina el programa si la entrada no es algun n�mero 
    }

    cout << "Escribe el segundo n�mero: ";
    if (!(cin >> num2)) { // Validaci�n de entrada nuevamente
    setlocale(LC_ALL, "");
        cout << "Error: Por favor, ingrese un n�mero v�lido." << endl;
        return 1;
    }

    // Operaciones a realizar  declaramos todas double de igualmanera para ocupar decimales
    double suma = num1 + num2;
    double resta = num1 - num2;
    double multiplicacion = num1 * num2; 

    // Verificar divisi�n entre 0 por eso la dej� aparte, adem�s importante aclarar que en c++ los simbolos son importantes
    //el simbolo + es suma, el simbolo - o gui�n alto es resta, el * asterisco significa multiplicaci�n...
	//  y finaalmente el simbolo / es la divisi�n para que el lenguaje c++ pueda realizar las correspondientes operaciones.
    if (num2 != 0) {
        double division = num1 / num2;
        // Mostrar resultados
        cout << "La suma es: " << suma << endl;
        cout << "La resta es: " << resta << endl;
        setlocale(LC_ALL, "");
        cout << "La multiplicaci�n es: " << multiplicacion << endl;
        cout << "La divisi�n es: " << division << endl;
    } else {
        cout << "La suma es: " << suma << endl;
        cout << "La resta es: " << resta << endl;
        setlocale(LC_ALL, "");
        cout << "La multiplicaci�n es: " << multiplicacion << endl;
        cout << "Error: No se puede dividir entre cero." << endl;
    }

    return 0;
}

